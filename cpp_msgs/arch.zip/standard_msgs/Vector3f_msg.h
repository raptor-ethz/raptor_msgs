#pragma once
#include <string>

namespace cpp_msg {

struct Vector3f_msg {

  float x;
  float y;
  float z;
};

} // namespace cpp_msg