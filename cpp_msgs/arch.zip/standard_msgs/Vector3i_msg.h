#pragma once
#include <string>

namespace cpp_msg {

struct Vector3i_msg {

  int x;
  int y;
  int z;
};

} // namespace cpp_msg