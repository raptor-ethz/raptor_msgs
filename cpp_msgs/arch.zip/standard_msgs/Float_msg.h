#pragma once

namespace cpp_msg {

struct Float_msg {
  float data;
};

} // namespace cpp_msg