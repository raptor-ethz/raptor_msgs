#pragma once
#include <string>

namespace cpp_msg {

struct String_msg {
  std::string data;
};
} // namespace cpp_msg