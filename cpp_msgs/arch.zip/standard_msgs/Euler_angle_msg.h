#pragma once

namespace cpp_msg {

struct Euler_angle_msg {

  float roll;
  float pitch;
  float yaw;
};

} // namespace cpp_msg