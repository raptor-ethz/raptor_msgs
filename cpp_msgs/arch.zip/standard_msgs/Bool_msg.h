#pragma once

namespace cpp_msg {

struct Bool_msg {
  bool data;
};

} // namespace cpp_msg