#pragma once

namespace cpp_msg {

struct Quaternion_msg {

  float w;
  float x;
  float y;
  float z;
};

} // namespace cpp_msg