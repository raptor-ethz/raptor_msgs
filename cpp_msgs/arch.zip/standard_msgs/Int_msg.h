#pragma once

namespace cpp_msg {

struct Int_msg {
  int data;
};

} // namespace cpp_msg